#ifndef SATELGIN_H
#define SATELGIN_H

#ifndef APIENTRY
#ifdef _WIN32
#define APIENTRY    __stdcall
#else
#define APIENTRY
#endif
#endif

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

/**
 * Obtém informações do Sat atualmente em uso pela biblioteca, contendo modelo,
 * hub, porta usb e número de série em formato Json.
 */
char *APIENTRY GetDeviceInfoAsJson(void);

/**
 * Lista todos os dispositivos SAT livres encontrados na máquina identificado
 * o seu modelo, hub e port usb, e número de serie retornado numa string json.
 */
char *APIENTRY ListAvailableSatAsJson(void);

int APIENTRY AbreSerialSAT(int commPort,
                           int nBaudRate,
                           int nBits,
                           int nParity,
                           int nStopBits);

/**
 * Configura a biblioteca para utilizar um SAT com o numero de serie
 * especificado.
 */
int APIENTRY FiltraSATNumSerie(const char *numero_serie);

/**
 * Configura a biblioteca para utilizar um SAT na porta USB especificada.
 */
int APIENTRY FiltraSATUsb(unsigned int bus,
                          unsigned int port);

/**
 * Configura a biblioteca para utilizar o primeiro SAT encontrado.
 *
 * Esse modo é habilitado por padrão.
 */
void APIENTRY LimpaFiltrosSAT(void);

/**
 * Permite que a biblioteca mantenha a conexão USB aberta
 * até que a aplicação seja finalizada
 *
 * Esse modo é habilitado por padrão
 */
void APIENTRY HabilitarConexaoContinua(void);

/**
 * Fecha a conexao USB apos cada resposta ser recebida,
 * permitindo que outras aplicacoes acessem o mesmo dispositivo
 *
 * Aviso: Nesse modo de operação o número de sessão
 * deve ser controlado externamente
 */
void APIENTRY DesabilitarConexaoContinua(void);

/**
 * Usa compressão de mensagens no protocolo, caso disponível.
 *
 * Esse modo é habilitado por padrão
 */
void APIENTRY HabilitarProtocoloComprimido(void);

/**
 * Usa mensagens no protocolo sem compressão.
 */
void APIENTRY DesabilitarProtocoloComprimido(void);

/**
 * Consulta o estado de conexão do SAT
 */
char *APIENTRY ConsultarSAT(int numSessao);

char *APIENTRY ConsultarStatusOperacional(int        numSessao,
                                          const char *codAtivacao);

char *APIENTRY EnviarDadosVenda(int        numSessao,
                                const char *codAtivacao,
                                const char *dadosVenda);

/**
 * Consulta as informações de log disponível no equipamento
 */
char *APIENTRY ExtrairLogs(int        numSessao,
                           const char *codAtivacao);

char *APIENTRY AtivarSAT(int        numSessao,
                         int        tipoCertificado,
                         const char *codAtivacao,
                         const char *cnpj,
                         int        cUF);

char *APIENTRY AssociarAssinatura(int        numSessao,
                                  const char *codAtivacao,
                                  const char *conjuntoCNPJ,
                                  const char *signAC);

char *APIENTRY ConsultarNumeroSessao(int        numSessao,
                                     const char *codAtivacao,
                                     int        numSessaoConsulta);

char *APIENTRY ConsultarUltimaSessaoFiscal(int        numSessao,
                                           const char *codAtivacao);

char *APIENTRY CancelarUltimaVenda(int        numSessao,
                                   const char *codAtivacao,
                                   const char *chave,
                                   const char *dadosCanc);

char *APIENTRY ConfigurarInterfaceDeRede(int        numSessao,
                                         const char *codAtivacao,
                                         const char *configRede);

char *APIENTRY AtualizarSoftwareSAT(int        numSessao,
                                    const char *codAtivacao);

char *APIENTRY BloquearSAT(int        numSessao,
                           const char *codAtivacao);

char *APIENTRY DesbloquearSAT(int        numSessao,
                              const char *codAtivacao);

char *APIENTRY TesteFimAFim(int        numSessao,
                            const char *codAtivacao,
                            const char *dadosVenda);

char *APIENTRY ComunicarCertificadoICPBRASIL(int        numSessao,
                                             const char *codAtivacao,
                                             const char *certificado);

char *APIENTRY TrocarCodigoDeAtivacao(int        numSessao,
                                      const char *codAtivacaoAtual,
                                      int        opcao,
                                      const char *novoCodigo,
                                      const char *novoCodigoConfirma);

/**
 * Gera número de sessão
 *
 * O número de sessão é garantido não foi utilizado pelo menos nas
 * últimas 100 comunicações.
 */
int APIENTRY GeraNumeroSessao(void);

/**
 * Retorna um vetor de caracteres, com a informação de versão. É de
 * responsabilidade da função que chamar `VersaoLib` de desalocar a
 * memoria.
 */
char *APIENTRY VersaoLib(void);

char *APIENTRY sat_log_variaveis(void);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

#endif /* SATELGIN_H */
