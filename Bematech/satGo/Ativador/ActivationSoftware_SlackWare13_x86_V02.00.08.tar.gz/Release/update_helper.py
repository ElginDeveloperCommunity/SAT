﻿# Script Python para atualização do SAT
import re
import base64
import sys
import datetime
import time
import os.path
from sys import platform
from ctypes import *
from random import randint

bemaConsultarStatus = ""
bemaExtrairLog = ""
bemaTesteFimAFim = ""
bemaEnviarDadosVenda = ""
bemaConfigurarInterfaceDeRede = ""

cupomXML = "<CFe><infCFe versaoDadosEnt=\"0.06\"><ide><CNPJ>16716114000172</CNPJ><signAC>SGR-SAT SISTEMA DE GESTAO E RETAGUARDA DO SAT</signAC><numeroCaixa>123</numeroCaixa></ide><emit><CNPJ>82373077000171</CNPJ><IE>111111111111</IE><IM>123123</IM><indRatISSQN>N</indRatISSQN></emit><dest><CNPJ>16716114000172</CNPJ><xNome>Fazenda</xNome></dest><det nItem=\"1\"><prod><cProd>0001</cProd><cEAN>0012345678905</cEAN><xProd>PRODUTO 1</xProd><NCM>47061000</NCM><CFOP>5001</CFOP><uCom>kg</uCom><qCom>1.0000</qCom><vUnCom>25.00</vUnCom><indRegra>A</indRegra></prod><imposto><vItem12741>1.00</vItem12741><ICMS><ICMS00><Orig>0</Orig><CST>00</CST><pICMS>10.00</pICMS></ICMS00></ICMS><PIS><PISNT><CST>04</CST></PISNT></PIS><COFINSST><vBC/><pCOFINS/></COFINSST></imposto></det><total /><pgto><MP><cMP>01</cMP><vMP>100.00</vMP></MP></pgto><infAdic /> </infCFe></CFe>"


def loadBemaSATLibrary(DynamicLibraryName):

    global bemaAtualizarSoftwareSAT
    global bemaConsultarStatus
    global bemaExtrairLog
    global bemaTesteFimAFim
    global bemaEnviarDadosVenda
    global bemaConfigurarInterfaceDeRede

    print "Carregando " + DynamicLibraryName
    if os.path.isfile(DynamicLibraryName):
        print "Biblioteca encontrada"
    else:
        print "Biblioteca não encontrada"
	sys.exit(0)

    if platform == "linux" or platform == "linux2":
        library = CDLL(DynamicLibraryName)
    elif platform == "win32":
        library = WinDLL(DynamicLibraryName)

    
    if not library:
        raise ValueError("Erro ao carregar biblioteca dinâmica: " + DynamicLibraryName);

    print "Sucesso ao carregar bilioteca: " + DynamicLibraryName

    bemaAtualizarSoftwareSAT = library['AtualizarSoftwareSAT']
    bemaConsultarStatus = library['ConsultarStatusOperacional']
    bemaTesteFimAFim = library['TesteFimAFim']
    bemaExtrairLog = library['ExtrairLogs']
    bemaEnviarDadosVenda = library['EnviarDadosVenda']
    bemaConfigurarInterfaceDeRede = library['ConfigurarInterfaceDeRede']

    if not bemaConsultarStatus or not bemaExtrairLog or not bemaTesteFimAFim or not bemaEnviarDadosVenda or not bemaConfigurarInterfaceDeRede:
        raise ValueError('Erro ao carregar funções da ' + str(DynamicLibraryName))

    print "Sucesso ao carregar funções dinamicamente";

    bemaAtualizarSoftwareSAT.restype = c_char_p
    bemaConsultarStatus.restype = c_char_p
    bemaExtrairLog.restype = c_char_p;
    bemaTesteFimAFim.restype = c_char_p;    
    bemaEnviarDadosVenda.restype = c_char_p;
    bemaConfigurarInterfaceDeRede.restype = c_char_p
    return library


def generateRandomSessionNumber() :
    return randint(0, 999999)

def extrairLogs(activationCode):
    return bemaExtrairLog(c_int(generateRandomSessionNumber()), c_char_p(activationCode))

def update(activationCode):
    return bemaAtualizarSoftwareSAT(c_int(generateRandomSessionNumber()), c_char_p(activationCode))

def testeFimAFim(activationCode):
    return bemaTesteFimAFim(c_int(generateRandomSessionNumber()), c_char_p(activationCode), c_char_p("adflaksjdflkasjdfkladflaksjdflkasj"));

def enviarDadosVenda(activationCode):
    return bemaEnviarDadosVenda(c_int(generateRandomSessionNumber()), c_char_p(activationCode), c_char_p(cupomXML));

def configurarInterfaceDeRede(activationCode, xmlConfig):
    return bemaConfigurarInterfaceDeRede(c_int(generateRandomSessionNumber()), c_char_p(activationCode), c_char_p(xmlConfig));

#Extrai, ordena e retorna registro mais futurista a partir de log já DECODIFICADO (BASE64)
def getMostAdvancedDateLog(log):
    '''
    datahora|processo|erro/info|detalhamento
    “datahora” é o carimbo de tempo no formato: AAAAMMDDhhmmss;
    “processo" é o autor ou os autores do processo, podendo ser: AC-SAT / SAT / SAT-AC / SAT-SEFAZ / SEFAZ-SAT
    '''
    regex = "(\d{14})\|(";
    processList = "AC-SAT|SAT|SAT-AC|SAT-SEFAZ|SEFAZ-SAT"
    
    regex += processList + ")\|"
    
    regexGroups = re.findall(regex, log);
    if len(regexGroups) == 0:
        raise ValueError('Não foram encontrados os padrões de data no log do SAT')
    
    #result = [ x[0] for x in regexGroups ];
    
    regexGroups.sort();
    
  #  print "Data mais antiga: " + regexGroups[0][0] + ".  Data mais avançada: " + regexGroups[-1][0];

    result = regexGroups[-1];

   # print "Registro de data mais futurista: " + str(result)
    return result[0]

def base64Decode(codedArray):
    return base64.b64decode(codedArray)

def consultaStatusOperacional(activationCode):
    return bemaConsultarStatus(c_int(generateRandomSessionNumber()), c_char_p(activationCode))
#   return "826935|10000|Resposta com Sucesso|||900011585|static|010.012.200.018|00:07:25:a1:75:14|255.255.000.000|010.012.010.011|010.012.020.005|000.000.000.000|CONECTADO|ALTO|1870127104|1179033600|20170323155433|01.01.00|0.06|35170382373077000171599000115850021819513321|||20170323143705|20170323143942|20170323|20220323|0";


def getCertificateExpirationDate(activationCode):
    operationalStatus = consultaStatusOperacional(activationCode)
    operationalStatusSplit = operationalStatus.split('|')

    if len(operationalStatusSplit) != 28:
        raise ValueError('Quantidade de parâmetros do resultado da consulta de status operacional não é válido (!28): ' + operationalStatus)

    certificateExpirationDate = operationalStatusSplit[-2]
    if not re.match(r'\d{6}', certificateExpirationDate):
        raise ValueError('Suposto valor de data de expiração do certificado não é válido: ' + certificateExpirationDate)

    return certificateExpirationDate + "0" * 6

def extractLogFromSAT(activationCode):

    completeLog = extrairLogs(activationCode)
    completeLogSplit = completeLog.split('|')

    if len(completeLogSplit) != 6:
        print "Retorno do SAT: " + completeLog
        raise ValueError('Quantidade de parâmetros do resultado da extração de log não é válido (!6): ' + completeLog)

    completeBase64CodedLog = completeLogSplit[5]
    decodedLog = base64Decode(completeBase64CodedLog)
    return decodedLog

def getExpiredDateRatio(activationCode):

    certificateExpirationDate = getCertificateExpirationDate(activationCode)
    if len(certificateExpirationDate) == 0:
        raise ValueError('Erro ao obter data de expiração do certificado do SAT')
    print "Data de expiração do certificado: " + certificateExpirationDate

    decodedLog = extractLogFromSAT(activationCode)
    if decodedLog is None:
        raise ValueError('Erro ao decodificar log do SAT')

    ratio0 = displayProgressExpirationDateRatio(certificateExpirationDate, decodedLog[0: 100* 1024])
    ratio1 = displayProgressExpirationDateRatio(certificateExpirationDate, decodedLog[100 * 1024: 400* 1024])
    ratio2 = displayProgressExpirationDateRatio(certificateExpirationDate, decodedLog[400 * 1024: 800* 1024])

    print "0: " + str(ratio0)
    print "1: " + str(ratio1)
    print "2: " + str(ratio2)

    mostAdvancedDateLog = getMostAdvancedDateLog(decodedLog)
    print "Data mais avançada do Log: " + mostAdvancedDateLog

    return (ratio0, ratio1, ratio2)

def rotateLog(activationCode, iterations):

    dateRatio = getExpiredDateRatio(activationCode)

    if not isDangerousToUpdate(dateRatio):
        return False

    for i in range(0, iterations):
        resp = testeFimAFim(activationCode)
        if i % 4 == 0:
            sys.stdout.write("\r| === | === | === | === |")
            sys.stdout.flush()
        elif i % 4 == 1:
            sys.stdout.write("\r/ === / === / === / === /")
            sys.stdout.flush()
        elif i % 4 == 2:
            sys.stdout.write("\r- === - === - === - === -")
            sys.stdout.flush()
        else:
            sys.stdout.write("\r\\ === \\ === \\ === \\ === \\")
            sys.stdout.flush()

        if dateRatio[0] > 0:
            configurarInterfaceDeRede(activationCode, "<>")

    return isDangerousToUpdate(dateRatio)

def isDangerousToUpdate(ratio):
    return ratio[0] > 0 or ratio[1] > 0 or ratio[2] > 0

def displayProgressExpirationDateRatio(certificateExpirationDate, log):
    '''
    datahora|processo|erro/info|detalhamento
    “datahora” é o carimbo de tempo no formato: AAAAMMDDhhmmss;
    “processo" é o autor ou os autores do processo, podendo ser:
    AC-SAT / SAT / SAT-AC / SAT-SEFAZ / SEFAZ-SAT
    '''
    regex = "(\d{14})\|("
    processList = "AC-SAT|SAT|SAT-AC|SAT-SEFAZ|SEFAZ-SAT"
    regex += processList + ")\|"
    regexGroups = re.findall(regex, log)
    if len(regexGroups) == 0:
        return -1
        #raise ValueError('Não foram encontrados os padrões de data no log do SAT')
    dates = [x[0] for x in regexGroups]
    for i in range(len(dates) - 1, 0, -1):
        if dates[i] > certificateExpirationDate:
            return log.rfind(dates[i]) / (len(log) * 1.0)
    return -1

    
def runApp():
    #sys.stdout = open(os.devnull, 'w') #desabilita print
    print "Esse aplicativo ira verificar se a atualizacao do SAT e segura"
    print "Esse processo podera levar varios minutos..."
    if platform == "linux" or platform == "linux2":
        BemaDLL = loadBemaSATLibrary("./libbemasat.so")
    elif platform == "win32":
        BemaDLL = loadBemaSATLibrary(".\BemaSAT.dll")
    
    ActivationCode = sys.argv[1]
    sys.stdout.flush()
    print "Codigo de ativacao digitado: " + str(ActivationCode)
    print "Verificando atualizacao segura do SAT"
       
    ratio = getExpiredDateRatio(ActivationCode)
    print datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sys.stdout.flush()
    result = isDangerousToUpdate(ratio)
    print "O update e seguro: " + ("Nao, \nTentando resolver problema... " if result else "Sim")
    sys.stdout.flush()

    numberOfIterations = 0
    rotation = 100
    while result:
        numberOfIterations += 1
        result = rotateLog(ActivationCode, rotation)
        sys.stdout.flush()
    print "Atualizacao e segura apos " + str(numberOfIterations)  + " iteracoes"
    print "Problema resolvido. \nAtualizando SAT"
    print "Este processo pode ser demorado, antes de usar o SAT verifique que todos os leds do aparelho estao normais!"
    print datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    sys.stdout.flush()
    sys.exit(1)


runApp()
