import sat
import base64


while True:
    print('\n*************************************************')
    print('**************** ATIVADOR SAT *******************')
    print('*************************************************\n')
    codAtivacao = str(input("DIGITE CÓDIGO DE ATIVAÇÃO OU 'TROCAR' PARA TROCAR CÓDIGO : ")).upper()
    if(codAtivacao=="TROCAR"):
        codAtivacao = str(input("CÓDIGO DE ATIVAÇÃO: "))
        option = int(input("1 - CÓDIGO DE ATIVAÇÃO | 2 CÓDIGO DE ATIVAÇÃO DE EMERGÊNCIA: "))
        new_code = str(input("NOVO CÓDIGO DE ATIVAÇÃO: "))
        new_code_confirmation = str(input("CONFIRME O NOVO CÓDIGO DE ATIVAÇÃO: "))
        ret = sat.trocar_codigo_de_ativacao(sat.gera_numero_sessao(),codAtivacao,option, new_code, new_code_confirmation)
        print(ret)
        codAtivacao=new_code        
    if not codAtivacao:
        codAtivacao = '123456789'
    ret = sat.consultar_status_operacional(sat.gera_numero_sessao(),codAtivacao)
    ret_splitlogin = ret.split("|")
    if(ret_splitlogin[1]=="10000"):
        break
    if(ret_splitlogin[1]=="10001"):
        print(ret_splitlogin[2])
        op = int(input("1 - Tentar novamente | 0 - Sair: "))
        if(op==0):
            break        
    else:
        print(ret)
        op = int(input("1 - Tentar novamente | 0 - Sair: "))
        if(op==0):
            break


while True:
    if(ret_splitlogin[1]!="10000"):
        break
    print("\n--------------------------------------\n")
    print("            MENU SAT\n")
    print("1  - Consultar Sat")
    print("2  - Consultar Status")
    print("3  - Extrair Logs")
    print("4  - Atualizar Sat")
    print("5  - Trocar Codigo de Ativação")
    print("6  - Bloquear Sat")
    print("7  - Desbloquear Sat")
    print("8  - Recuperar chave AC")
    print("9  - Ativar SAT")
    print("10 - Associar Assinatura")
    print("0  - SAIR\n")
    print("--------------------------------------")

    escolha = input ("\nDigite a opção desejada: ")

    if escolha == "0":
        while True:
            sair = input("Deseja sair (S / N): ").upper()
            if sair == "S":
                print("PRESSIONE ENTER PARA ENCERRAR")
                exit()
            elif sair == "N":
                break  # Sai do loop interno se a opção for "N"
            else:
                print("Opção inválida")
                            
    elif escolha == "1":
        ret = sat.consultar_sat(sat.gera_numero_sessao())
        print('\n',ret)
        
    elif escolha == "2":
        ret = sat.consultar_status_operacional(sat.gera_numero_sessao(),codAtivacao)
        print('\n',ret)
        
    elif escolha == "3":
        ret = sat.extrair_logs(sat.gera_numero_sessao(),codAtivacao)
        ret_split = ret.split("|")
        if(len(ret_split)>=5):
            input_string=ret_split[5]
            base64_converted_string = input_string.encode("utf-8")
            decode = base64.b64decode(base64_converted_string)
            converted_string = decode.decode("utf-8")
            arquivo = open('log.txt','w')
            arquivo.writelines(converted_string)
            arquivo.close()
            print("Arquivo log.txt criado na pasta raiz do ativador")
        else:
            print('\n',ret)
            
    elif escolha == "4":
        ret = sat.atualizar_software_sat(sat.gera_numero_sessao(),codAtivacao)
        print('\n',ret)
        
    elif escolha == "5":
        codAtivacao = str(input("CÓDIGO DE ATIVAÇÃO: "))
        option = int(input("1 - CÓDIGO DE ATIVAÇÃO | 2 CÓDIGO DE ATIVAÇÃO DE EMERGÊNCIA: "))
        new_code = str(input("NOVO CÓDIGO DE ATIVAÇÃO: "))
        new_code_confirmation = str(input("CONFIRME O NOVO CÓDIGO DE ATIVAÇÃO: "))
        ret = sat.trocar_codigo_de_ativacao(sat.gera_numero_sessao(),codAtivacao,option, new_code, new_code_confirmation)
        print('\n',ret)
        codAtivacao=new_code
        
    elif escolha == "6":
        ret = sat.bloquear_sat(sat.gera_numero_sessao(),codAtivacao)
        print('\n',ret)
        
    elif escolha == "7":
        ret = sat.desbloquear_sat(sat.gera_numero_sessao(),codAtivacao)
        print('\n',ret)
        
    elif escolha == "8":
        ret = sat.extrair_logs(sat.gera_numero_sessao(),codAtivacao)
        ret_split = ret.split("|")
        if(len(ret_split)>=5):
            input_string=ret_split[5]
            base64_converted_string = input_string.encode("utf-8")
            decode = base64.b64decode(base64_converted_string)
            converted_string = decode.decode("utf-8")
            converted_string = converted_string.split("\n")
            for i in reversed(converted_string):
                if (i.find("Assinatura AC ->")>0):
                    print(i[i.find("Assinatura AC ->"):])
                    break

        else:
            print('\n',ret)

    elif escolha == "9":
        cnpj = str(input('Digite o CNPJ: '))
        UF = str(input('Digite a sigla do Estado: ')).upper()
        ret = sat.ativar_sat(sat.gera_numero_sessao(), 1, codAtivacao,cnpj, UF)
        print('\n',ret)

    elif escolha == "10":
        cnpjSH = str(input('Digite o CNPJ da Software House: '))
        assinaturaAC = str(input('Cole a assinatura digital: '))
        ret = sat.associar_assinatura(sat.gera_numero_sessao(), codAtivacao, cnpjSH, assinaturaAC)
        print('\n', ret)
        
    else:
        print("OPÇÃO INVÁLIDA")
